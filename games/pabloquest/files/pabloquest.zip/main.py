import libtcodpy as libtcod
import math
import textwrap
import generator
import pickle

SCREEN_HEIGHT = 30
SCREEN_WIDTH = int(SCREEN_HEIGHT*16/9)
 
#size of the map
MAP_WIDTH = SCREEN_WIDTH
MAP_HEIGHT = SCREEN_HEIGHT
 
#parameters for dungeon generator
ROOM_MAX_SIZE = 10
ROOM_MIN_SIZE = 6
MAX_ROOMS = 30
MAX_ROOM_MONSTERS = 3
MAX_ROOM_ITEMS = 2
MAX_LEVEL=20

#parameters of message log
MSG_X = 1
MSG_WIDTH = SCREEN_WIDTH - 2
MSG_HEIGHT = 0

#parameters for menu lists
INVENTORY_WIDTH = SCREEN_WIDTH-2
INVENTORY_MAX = 15

#ITEMS
EQUIPABLE_LIST_NAME=['weapon','shield','armor','helm','ring','bow']
EQUIPABLE_LIST_ICON=['/','o',']','n',',','(']
EQUIPABLE_LIST_SLOT=['r_hand','l_hand','body','head','finger','r_hand']
MONSTER_NAME_LIST=[]
 
FOV_ALGO = 0  #default FOV algorithm
FOV_LIGHT_WALLS = True  #light walls or not
NEW_MSG = ''

LIMIT_FPS = 20  #20 frames-per-second maximum
 
 
color_dark_wall = libtcod.dark_grey
color_light_wall = libtcod.grey
color_dark_ground = libtcod.black
color_light_ground = libtcod.light_yellow

class World:
    #the class for the world attributes
    def __init__(self,level=1):
        self.level=1 #actual level
        self.final_level=99   
        self.finished=False


class Tile:
    #a tile of the map and its properties
    def __init__(self, blocked, block_sight = None):
        self.blocked = blocked
 
        #all tiles start unexplored
        self.explored = False
 
        #by default, if a tile is blocked, it also blocks sight
        if block_sight is None: block_sight = blocked
        self.block_sight = block_sight
 
class Rect:
    #a rectangle on the map. used to characterize a room.
    def __init__(self, x, y, w, h):
        self.x1 = x
        self.y1 = y
        self.x2 = x + w
        self.y2 = y + h
 
    def center(self):
        center_x = (self.x1 + self.x2) / 2
        center_y = (self.y1 + self.y2) / 2
        return (center_x, center_y)
 
    def intersect(self, other):
        #returns true if this rectangle intersects with another one
        return (self.x1 <= other.x2 and self.x2 >= other.x1 and
                self.y1 <= other.y2 and self.y2 >= other.y1)
 
class Object:
    #this is a generic object: the player, a monster, an item, the stairs...
    #it's always represented by a character on screen.
    def __init__(self, x, y, char, name, color, blocks=False, fighter=None, ai=None, item=None,
                 door=None, special= None,back_color=libtcod.black,portal=None):
        self.x = x
        self.y = y
        self.char = char
        self.name = name
        self.oldname = name
        self.color = color
        self.back_color=back_color
        self.original_back_color=back_color
        self.blocks = blocks
        self.fighter = fighter
        if self.fighter:  #let the fighter component know who owns it
            self.fighter.owner = self
 
        self.ai = ai
        if self.ai:  #let the AI component know who owns it
            self.ai.owner = self
            
        self.item = item
        if self.item:  #let the Item component know who owns it
            self.item.owner = self

        self.door = door
        if self.door:  #let the Item component know who owns it
            self.door.owner = self
        self.portal =portal
        if self.portal:  #let the Item component know who owns it
            self.portal.owner = self
        
        self.special=special
        if special is not None:
            for element in special:
                element.owner = self
 
    def move(self, dx, dy):
        #move by the given amount, if the destination is not blocked
        if not is_blocked(self.x + dx, self.y + dy):
            self.x += dx
            self.y += dy


 
 
    def move_towards1(self, target_x, target_y):                

        distance= 10000
        dx= 0
        dy= 0
        dx_temp=0
        dy_temp=0
        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):
                #if it is in fov and not blocked
                if libtcod.map_is_in_fov(fov_map,x,y) and not is_blocked(x,y):
                    #if the distance at self is 1 square
                    if math.sqrt((x-self.x)** 2 + (y-self.y)** 2)<2:
                        dx_temp=target_x-x
                        dy_temp=target_y-y
                        new_distance=math.sqrt(dx_temp**2+dy_temp**2)#distance to player
                        #if this distance is lower
                        if new_distance<distance:
                            #pick that
                            distance=new_distance
                            dx=x-self.x
                            dy=y-self.y
                        #if doin nothing is better, do nothing
                        if distance>math.sqrt((target_x-self.x)** 2 + (target_y-self.y)** 2):
                            #do nothing
                            dx=0
                            dy=0

        self.move(dx, dy)

    def move_towards(self, target):
        my_map=libtcod.map_new(MAP_WIDTH,MAP_HEIGHT)

        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):                
                if not map[x][y].blocked:
                    libtcod.map_set_properties(my_map, x, y, True, True)
                #if target==player and map[x][y].blocked==False and player.fighter.alignment==self.fighter.alignment:
                    #libtcod.map_set_properties(my_map, x, y, True, True)                   
                    
                    
                
        libtcod.map_set_properties(my_map, target.x, target.y, True, True)
        libtcod.map_set_properties(my_map, self.x, self.y, True, True)
        path = libtcod.path_new_using_map(my_map)
        libtcod.path_compute(path,self.x,self.y,target.x,target.y)
        if libtcod.path_size(path)>0:
            x,y=libtcod.path_get(path, 0)
        else:
            x=self.x
            y=self.y

        dx=0
        dy=0
        if x>self.x:
            dx=1        
        if x<self.x:
            dx=-1
        if y>self.y:
            dy=1        
        if y<self.y:
            dy=-1

        self.move(dx,dy)
         


 
    def distance_to(self, other):
        #return the distance to another object
        dx = other.x - self.x
        dy = other.y - self.y
        return math.sqrt(dx ** 2 + dy ** 2)
 
    def send_to_back(self):
        #make this object be drawn first, so all others appear above it if they're in the same tile.
        global objects
        objects.remove(self)
        objects.insert(0, self)
 
    def draw(self):
        #only show if it's visible to the player
        if libtcod.map_is_in_fov(fov_map, self.x, self.y):
            libtcod.console_put_char_ex(con, self.x, self.y,self.char, self.color, self.back_color)
        #show explored doors
        elif self.door:
            if map[self.x][self.y].explored:
                libtcod.console_put_char_ex(con, self.x, self.y,self.char, self.color, color_dark_wall)
        elif self.portal:
            if map[self.x][self.y].explored:
                libtcod.console_put_char_ex(con, self.x, self.y,self.char, self.color, self.back_color)
                
                    
    def clear(self):
        #erase the character that represents this object
        if libtcod.map_is_in_fov(fov_map, self.x, self.y):
            libtcod.console_put_char_ex(con, self.x, self.y, '.', color_light_ground, libtcod.BKGND_NONE) 

class Portal:
    def __init__(self):
        self.explored=False
        if world.level<world.final_level:
            self.go_to=world.level+1
        if world.level==world.final_level:
            self.go_to=0
        
    def use(self):
        global game_state
        if self.owner.name is 'Exit':
            if not world.finished :
                msg('You cant escape from the dungeon yet!')
                return 1
            else:
                msg('You escape from the dungeon!')
                #the game finish
                game_state='dead'
        world.finished=False    
        world.level=self.go_to
        make_map()
        
        
            
    

class Door:
    def __init__(self):
        self.status='closed'
        
    def use(self,who):
        global fov_map
        opened=0
        if self.status=='closed':
            if who==player:
                msg("You open a "+self.owner.name+'.')
                self.status='open'
                self.owner.char=' '
                #self.owner.blocks=False
                map[self.owner.x][self.owner.y].block_sight=False
                map[self.owner.x][self.owner.y].blocked=False
                opened=1
                self.owner.send_to_back()
                
        elif self.status=='open':
            if who==player:
                if not is_blocked(self.owner.x,self.owner.y):
                    msg("You close a "+self.owner.name)
                    self.status='closed'
                    self.owner.char='#'
                    #self.owner.blocks=True
                    map[self.owner.x][self.owner.y].block_sight=True
                    map[self.owner.x][self.owner.y].blocked=True
                    opened=1
                    self.owner.send_to_back()
                    
                else:
                    msg('Something is blocking the '+self.owner.name)
                    
        fov_map = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):
                libtcod.map_set_properties(fov_map, x, y, not map[x][y].blocked, not map[x][y].block_sight)
        if opened:
            return 1
        else:
            return 'didnt-take-turn'

class Mage:
    def __init__(self,prob=10):
        self.charged=True
        self.probability=prob
        self.name='mage'
    def cast(self):
        spell=libtcod.random_get_int(0,1,len(SPELL_LIST))-1
        SPELL_LIST[spell](self.owner)
        
class Archer:
    def __init__(self):
        self.probability=70
        self.name='mage'
    def cast(self):
        fire_ranged(self.owner)

class Zombie:
    def __init__(self):
        self.probability=1
        self.name='zombie'
        self.resurrection_probability=40
    def cast(self):
        self.probability=self.probability+1-1
    
        
    
class Fighter:
    #combat-related properties and methods (monster, player, NPC).
    def __init__(self, hp, AC, max_damage, hit=0, death_function=None, exp=0,lvl=1,
                 target=None,alignment='enemy'):
        self.max_hp = hp
        self.hp = hp
        self.basehp = hp
        self.AC = AC
        self.baseAC = AC
        self.max_damage = max_damage
        self.basedamage = max_damage
        self.hit=hit
        self.basehit=hit
        self.death_function = death_function
        self.wait=0
        self.exp=exp
        self.lvl=lvl
        self.alignment=alignment
        self.target=target
        self.paralysis=0
        self.torch_radious=10
        self.torch_radious_init=10
        self.blindness=0
         

    def checkwait(self):
        if self.wait==0:
            return 'no waiting'
        else:
            self.wait-=1
            return 'waiting'

    def heal(self, amount):
        #heal by the given amount, without going over the maximum
        self.hp += amount
        if self.hp > self.max_hp:
            self.hp = self.max_hp
 
    def attack(self, enemy):
        global NEW_MSG
        #roll 1d20+hitchance and check it is >= targets AC
        dice=libtcod.random_get_int(0,1,20)


        #roll damage is was a hit
        damage=0
        if dice+self.hit>=enemy.fighter.AC or dice==19:
            damage = libtcod.random_get_int(0,1,self.max_damage)
            if dice==20:
                damage=+damage #double damage if critical
                
            
        
 
        if damage > 0:
            #make the target take some damage
            #buf=str(NEW_MSG)
            msg( self.owner.name.capitalize() + ' hits ' + enemy.name+'.' )
            
            enemy.fighter.take_damage(damage,self)            
                
        else:
            msg( self.owner.name.capitalize() + ' misses!')
            
    def get_experience(self,exp_points):
        global player
        self.exp+=exp_points
        if self.alignment == player.fighter.alignment:            
            #if it is the player or allyes            
            if self.exp>self.lvl*10:
                #level up!
                self.advancelevel()


    def advancelevel(self):
        # messages until now
        #show messages
        global NEW_MSG
        message(NEW_MSG)
        # delete mesages    
        del NEW_MSG
        NEW_MSG = ''

        self.lvl+=1
        self.exp=0
        header=self.owner.name+' gain one level! Choose a characteristic to upgrade!\n'
        options=['Life','Damage','Hit bonus','Defense']
        chosen=None
        while chosen is None: 
            chosen=menu(header,options,SCREEN_WIDTH-2)
            if chosen == 0:
                self.basehp+=3
            if chosen == 1:
                self.basedamage+=1
            if chosen == 2:
                self.basehit+=1
            if chosen == 3:
                self.baseAC+=1
        
        msg(self.owner.name+' s '+str(options[chosen])+' is improved!')
        actualizebonuses()
 
    def take_damage(self,damage,killer):
        #apply damage if possible
        if damage > 0:
            self.hp -= damage
            projectile_graphic(self.owner.char,libtcod.black,self.owner.x+1,self.owner.y,self.owner.x,self.owner.y)
            #posibility of break paralyce
            if libtcod.random_get_int(0,0,100)<50:
                self.paralysis=0
            #check for death. if there's a death function, call it
            if self.hp <= 0:
                self.paralysis=0
                function = self.death_function(self.owner,killer)
                if function is not None:
                    function(self.owner)
                return 'target died'                
            return 0
    def check_status(self):
        #check blindness
        if self.blindness>0:
            self.blindness-=1
            self.torch_radious=1
            if self.blindness==0:
                self.torch_radious=self.torch_radious_init
                msg(self.owner.name+' is no longer blind!')
        if self.paralysis>0:
            self.paralysis-=1
            self.owner.back_color=libtcod.white
            return 'skip'
        else:
            
            self.owner.back_color=self.owner.original_back_color
        return 'no skip'
    def play(self):
        if self.check_status()!='skip':
            if self.checkwait()=='no waiting':
                return self.owner.ai.take_turn()
            
        
                
class AiPlayer:
    #Ai for player
    global player
    global player_action
    def take_turn(self):
    #handle keys and exit game if needed
    #see if player has to wait
        
        if player.fighter.checkwait()=='no waiting':            
            player_action = handle_keys()
        else:
            player_action=1 #if he has to wait player action takes turn
        return player_action
    
class BasicMonster:
    #AI for a basic monster.
    def take_turn(self):
        #a basic monster takes its turn. if you can see it, it can see you
        
        monster = self.owner            

        #eliminate previous target if it is dead or too far away
        if monster.fighter.target is not None:
            if monster.fighter.target.fighter.hp<0 or not libtcod.map_is_in_fov(fov_map, monster.fighter.target.x, monster.fighter.target.y):
                monster.fighter.target=None
                
        #if no target get new one
        if monster.fighter.target == None:
            get_target(monster)

        #provisional get target
        get_target(monster)
            
               
 
        
        #if no target skip turn
        if monster.fighter.target == None:
            #if is ally go to aifollower
            if monster.fighter.alignment==player.fighter.alignment:
                monster.ai=AIfollower()
                monster.ai.owner=monster
            return
        
        
        #if we have a target, it can fuck spells
        if monster.special:
            for element in monster.special:
                
                if libtcod.random_get_int(0, 0, 100)<element.probability:#probability of magic
                    element.cast()
                    return
           
        if 1<2:
            #move towards player if far away
            if monster.distance_to(monster.fighter.target) >= 2:
                monster.move_towards(monster.fighter.target) 
            #close enough, attack! (if the player is still alive.)
            elif monster.fighter.target.fighter.hp > 0:
                monster.fighter.attack(monster.fighter.target)


class AIfollower:
    def take_turn(self):
        
        monster=self.owner
        follow=player
        #see if player is not in fov
        if not libtcod.map_is_in_fov(fov_map, player.x, player.y):
            #pick another ally
            for element in objects:
                if element.fighter and element.fighter.alignment == monster.fighter.alignment and libtcod.map_is_in_fov(fov_map, element.x, element.y): 
                    follow=element
        follow=player
        #move towards player if far away
        if monster.distance_to(follow) >= 2:
            monster.move_towards(follow)
        #if there is a target change AI to basicmonster
        get_target(monster)
        if monster.fighter.target != None:
            monster.ai=BasicMonster()
            monster.ai.owner=monster
            
            


           
class AIstop:
    def take_turn(self):
        monster=self.owner
    
def get_target(self):
    #return the closest monster of opposite alignment
    global fov_map
    
    self.fighter.target=closest_monster(self,self.fighter.torch_radious,self.fighter.alignment)
        

    

 
class Item:
    global player
    #an item that can be picked up,examined and used.
    def __init__(self, use_function=None, time=0, quantity=None, object_type='No type defined',
                 description=None,equip_class=None):
        self.use_function = use_function
        self.time=time
        self.quantity=quantity
        self.type=object_type
        self.description=description
        self.equip_class=equip_class
        

        if self.equip_class:  #let the fighter component know who owns it
            self.equip_class.owner = self
        
        
    def pick_up(self):
        global inventory
        #add to the player's inventory and remove from the map
        if self.quantity==None: #if is no apilable
            if len(inventory) >= INVENTORY_MAX:
                msg ('Your inventory is full!')
            else:
                inventory.append(self.owner)
                objects.remove(self.owner)
                msg('You picked up a ' + self.owner.name + '!')
                player.fighter.wait+=1 #pass 1 turn
        else:#if is apilable
            createnewslot=1
            for item in inventory:
                if item.item.type==self.type:
                    #dont create a new slot
                    createnewslot=0
                    objects.remove(self.owner)
                    msg('You stack up ' + self.owner.name + '!')
                    player.fighter.wait+=1 #pass 1 turn
                    for item in inventory:
                        if item.item.type=='gold coins':
                            item.item.quantity+=self.quantity
                            item.name=str(item.item.quantity) + ' gold coins'                    
                
            
            

                        
            if createnewslot:
                #use a new slot to start counting gold coins
                if len(inventory) >= INVENTORY_MAX:
                    msg ('Your inventory is full, cannot pick up ' + self.owner.name + '.')
                else:
                    inventory.append(self.owner)
                    objects.remove(self.owner)
                    msg('You picked up a ' + self.owner.name + '!')
                    player.fighter.wait+=1 #pass 1 turn
  
            
                

    def drop(self):
        #add to the map and remove from the player's inventory. also, place it at the player's coordinates
        objects.append(self.owner)
        inventory.remove(self.owner)
        self.owner.x = player.x
        self.owner.y = player.y
        msg('You dropped a ' + self.owner.name + '.', libtcod.yellow)
        player.fighter.wait+=1 #pass 1 turn
        #if the item was equipped change name
        
        if self.equip_class is not None and self.equip_class.equipped:
                self.owner.name=self.owner.oldname

    def use(self):
        #just call the "use_function" if it is defined
        if self.use_function is None:
            msg('The ' + self.owner.name + ' cannot be used.')
        else:
            self.use_function(player)
            inventory.remove(self.owner)  #destroy after use, unless it was cancelled for some reason
            player.fighter.wait+=self.time

                
    def describe(self):
        options=[]
        if self.description is None:
            msg('No description available')
        else:
            #if is equipable show stats
            header=self.description+'\n'
            if self.equip_class is not None:
                options.append('Hit point bonus:'+str(self.equip_class.maxhp))
                options.append('Damage:'+str(self.equip_class.maxdmg))
                options.append('Bonus to hit:'+str(self.equip_class.hit))
                options.append('Defense:'+str(self.equip_class.ac))
            #if is magical and charged show it
            if self.owner.special and self.owner.special[0].charged:
                options.append('Magically charged')
                
                

            menu(header,options,SCREEN_WIDTH-2)
                
            
                


                
class Equipable:
    global player
    def __init__(self,slot=None,hit=0,maxhp=0,ac=0,maxdmg=0):
        self.slot=slot
        self.equipped=False
        self.hit=hit
        self.maxhp=maxhp
        self.ac=ac
        self.maxdmg=maxdmg
    def equip(self):
        #if it is equipped, unequip it
        if self.equipped:
            #unequip it
            self.owner.owner.name=self.owner.owner.oldname
            msg('You unequip the '+self.owner.owner.name)
            self.equipped=False
            inventory.remove(self.owner.owner)
            inventory.append(self.owner.owner)
        else:
            #equip if possible
            #if the slot is empty, equip
            freeslot=1
            for item in inventory:
                if item.item.equip_class:
                    if item.item.equip_class.slot==self.slot and item.item.equip_class.equipped:
                        freeslot=0

            if freeslot==1:
                #equip
                msg('You equip the '+ self.owner.owner.name)
                self.equipped=True
                self.owner.owner.name='Equipped '+self.owner.owner.name
                inventory.remove(self.owner.owner)
                inventory.insert(0, self.owner.owner)

            else:
                msg('You can not equip')

            
            
        
 

    
def getexp():
    roll=libtcod.random_get_int(0, 0 , 1000-1)
    #exponential
    roll=(roll**3/1000**2)/10+1
    return roll
def list_of_enemies():
    fileObj = open("enemylist.txt","w")
    for i in range(100):
        roll=i+1
        lvl=int(round(roll*(MAX_LEVEL-1)/100+1))
        name_index=(int(round((roll-1)*(len(MONSTER_NAME_LIST))/100)))
        name=MONSTER_NAME_LIST[name_index]
        hp=int(round(roll*(MAX_LEVEL*1.5)/100+1)) #max 30 min 1
        AC=int(round(roll*(MAX_LEVEL*0.8)/100-2)) #max 20 min 8
        max_damage=int(round(roll*(MAX_LEVEL*0.8)/100+1)) #max 12 min 1
        hit=int(round(roll*MAX_LEVEL/100)) #max 15 min 0    
        
        fileObj.write('Name:'+name+'\tLvl:'+str(lvl)+'\thp:'+str(hp)+'\tAC:'+str(AC)+'\tmax_damage:'+str(max_damage)+'\tHit:'+str(hit)+'\n')
    fileObj.close()   


def generate_enemy(x,y,boss=False,summon=False,alignment='enemy'):
    global objects
    special=None
    get_this=False
    while get_this is False:
        roll=getexp()
        lvl=int(round(roll*(MAX_LEVEL-1)/100+1))
        if world.level+3>lvl and world.level-3<lvl:
            get_this=True   
    name_index=(int(round((roll-1)*(len(MONSTER_NAME_LIST))/100)))
    name=MONSTER_NAME_LIST[name_index]
    if name_index%2==0:
        color=libtcod.green
    else:
        color=libtcod.red
    back_color=libtcod.black
    death_function=monster_death
    special_list=[]

    if boss:
        color=libtcod.black
        back_color=libtcod.red
        death_function=boss_death
        roll=roll*2
        
    hp=int(round(roll*(MAX_LEVEL*1.5)/100+1)) #max 30 min 1
    AC=int(round(roll*(MAX_LEVEL*0.8)/100-2)) #max 20 min 8
    max_damage=int(round(roll*(MAX_LEVEL*0.8)/100+1)) #max 12 min 1
    hit=int(round(roll*(MAX_LEVEL+2)/100))-2 #max 15 min 0       
    lvl=int(round(roll*(MAX_LEVEL-1)/100+1))
    
    alignment=alignment

    if libtcod.random_get_int(0, 0, 100)<10 and not boss:    
        special_list.append(Mage())
        color=libtcod.blue
        name+=' mage'
        lvl+=1

    if libtcod.random_get_int(0, 0, 100)<10 and not boss:
        special_list.append(Archer())
        color=libtcod.orange
        name+=' archer'
        lvl+=1
    if libtcod.random_get_int(0, 0, 100)<10 and not boss:
        special_list.append(Zombie())
        color=libtcod.light_gray
        name+=' zombie'
        lvl+=1
    if boss:
        special_list.append(Mage(20))
        special_list.append(Zombie())
        color=libtcod.black
        back_color=libtcod.red
        death_function=boss_death                
        name=name.capitalize()
        msg('You feel a dangerous presence...')
    exp=lvl
    if summon:
        back_color=libtcod.darker_violet   
    fighter_component=Fighter(hp=hp,AC=AC,max_damage=max_damage,hit=hit,
                              death_function=death_function,exp=exp,lvl=lvl,alignment=alignment)
    ai_component = BasicMonster()
    monster = Object(x,y,name[0],name,color,blocks=True,fighter=fighter_component,
                         ai=ai_component, special=special_list,back_color=back_color)

    objects.append(monster)
    
    return name

def generate_treasure(x,y,number=1,level=1):
    global objects
    #generates in the floor "number" items
    
    # 0-30 1d10 gold coins 
    # 30-60 equipable
    # 60-80 potion
    # 80-100 paralyce scroll
    for r in range(number):
        roll=libtcod.random_get_int(0, 0, 100)
        if roll<30:
            #generate gold coins
            #num_goldcoins=libtcod.random_get_int(0,1,10)
            num_goldcoins=level
            description= "They are golden coins"
            item_component=Item(quantity=num_goldcoins,object_type='gold coins',description=description)
            item = Object(x,y,'$',str(num_goldcoins) +' gold coins',libtcod.yellow,item=item_component)
                            
                
        elif roll <60:
            #generate equipable in random slot
            item=libtcod.random_get_int(0,1,len(EQUIPABLE_LIST_NAME))-1
            
            slot=EQUIPABLE_LIST_SLOT[item]
            icon=EQUIPABLE_LIST_ICON[item]
            name=EQUIPABLE_LIST_NAME[item]
            item_type=name
            description='A '+name+':'
            hit=getexp()*level/100
            maxhp=getexp()*level/100
            ac=getexp()*level/100
            maxdmg=getexp()*level/100
            
            equip_class=Equipable(slot,hit,maxhp,ac,maxdmg)            
            
            color=libtcod.white
            mage_comp=None
            if libtcod.random_get_int(0, 0, 100)<5:
                mage_comp=[]
                mage_comp.append(Mage())
                name='magical '+name
                color=libtcod.blue
            suma=hit+maxhp+ac+maxdmg
            name+=' ['+str(suma)+']'              
                
            description='A '+name+':'
            item_component=Item(object_type=item_type,description=description,equip_class=equip_class)
            item= Object(x,y,icon,name,color,item=item_component,special=mage_comp)
            
        
        #elif roll<80:
            #generate health potion
         #   item_component = Item(use_function=cast_heal,time=2) 
         #   item = Object(x, y, '!', 'healing potion', libtcod.violet, item=item_component)
            
        else:
            #generate scroll paralyce
            #create paralyze scroll
            item=libtcod.random_get_int(0,1,len(SPELL_LIST))-1            
            name= 'scroll of '+SPELL_LIST_NAME[item]
            description=SPELL_LIST_DESCRIPTION[item]
            if libtcod.random_get_int(0,0,100)<50:
                name='misterious scroll'
                description=None
            item_component = Item(use_function=SPELL_LIST[item],time=1,description=description)
            item = Object(x, y, '?',name, libtcod.light_yellow, item=item_component)
            
        objects.append(item)
        item.send_to_back()  #items appear below other objects

    


def menu(header, options, width,main=0):
    #render the screen
    if main==0:
        render_all() 
        libtcod.console_flush()
    
    
    if len(options) > 26: raise ValueError('Cannot have a menu with more than 26 options.')
    #calculate total height for the header (after auto-wrap) and one line per option
    header_height = libtcod.console_height_left_rect(con, 0, 0, width, SCREEN_HEIGHT, header)
    height = len(options) + header_height+2

    #create an off-screen console that represents the menu's window
    window = libtcod.console_new(width, height)
    blank='.'
    libtcod.console_set_foreground_color(window, libtcod.red)
    libtcod.console_set_background_color(window,libtcod.red)
    for i in range(SCREEN_WIDTH*SCREEN_HEIGHT-1):
        blank+='.'
    libtcod.console_print_left_rect(window, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, libtcod.BKGND_SET,blank)
    #  the header, with auto-wrap
    libtcod.console_set_foreground_color(window, libtcod.white)
    libtcod.console_print_left_rect(window, 0, 1, width, height, libtcod.BKGND_SET,header)
    #print all the options
    y = header_height
    letter_index = ord('a')
    for option_text in options:        
        text = '(' + chr(letter_index) + ') ' + option_text
        libtcod.console_print_left(window, 0, y+1, libtcod.BKGND_SET, text)        
        y += 1
        letter_index += 1
         
    #blit the contents of "window" to the root console
    x = SCREEN_WIDTH/2 - width/2
    y = SCREEN_HEIGHT/2 - height/2
    libtcod.console_blit(window, 0, 0, width, height, 0, 1, y, 1.0, 1)
    #present the root console to the player and wait for a key-press
    libtcod.console_flush()
    key = libtcod.console_wait_for_keypress(True)
    #convert the ASCII code to an index; if it corresponds to an option, return it
    index = key.c - ord('a')
    if index >= 0 and index < len(options): return index
    return None

def inventory_menu(header,item_type='all'):
    #show a menu with each item of the inventory as an option
    if len(inventory) == 0:
        options = ['Inventory is empty.']
    else:
        #all items
        if item_type=='all':            
            options = [item.name for item in inventory]

            
 
    index = menu(header, options, INVENTORY_WIDTH)
    #if an item was chosen, return it
    if index is None or len(inventory) == 0: return None
    return inventory[index].item


def msg(string,color=1):
    global NEW_MSG
    NEW_MSG+=string
            
def is_blocked(x, y):
    #first test the map tile
    
    
    if map[x][y].blocked:
        return True
 
    #now check for any blocking objects
    for objectz in objects:
        if objectz.blocks and objectz.x == x and objectz.y == y:
            return True
 
    return False
 
def create_room(room):
    global map
    #go through the tiles in the rectangle and make them passable
    for x in range(room.x1 + 1, room.x2):
        for y in range(room.y1 + 1, room.y2):
            map[x][y].blocked = False
            map[x][y].block_sight = False
 
def create_h_tunnel(x1, x2, y):
    global map
    #horizontal tunnel. min() and max() are used in case x1>x2
    for x in range(min(x1, x2), max(x1, x2) + 1):
        map[x][y].blocked = False
        map[x][y].block_sight = False
 
def create_v_tunnel(y1, y2, x):
    global map
    #vertical tunnel
    for y in range(min(y1, y2), max(y1, y2) + 1):
        map[x][y].blocked = False
        map[x][y].block_sight = False
 
def make_map():
    global map ,objects
    global fov_map
    temporal_objects=[]
    #destroy all the objects but the player
    for element in objects:
        if element.fighter is not None:        
            if element.fighter.alignment==player.fighter.alignment:
                temporal_objects.append(element)
    objects=[]
    objects=temporal_objects
    
    #fill map with "blocked" tiles
    map = [[ Tile(True)
        for y in range(MAP_HEIGHT) ]
            for x in range(MAP_WIDTH) ]
    


    if world.final_level==world.level:
        create_new_dungeon(4,0,True)
    else:
        create_new_dungeon()

        
    fov_map = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            libtcod.map_set_properties(fov_map, x, y, not map[x][y].blocked, not map[x][y].block_sight)
     
    #recharge the magical items
    advise=0
    for item in inventory:
        if item.item.equip_class and item.special:
            for element in item.special:
                if element.charged is not None:
                    if item.special[0].charged==False:
                        item.special[0].charged=True
                        advise=1
    if advise==1:
        msg('Your magic items are recharged!')
    return


def create_new_dungeon(number_of_rooms=20,probability_cor=30,final_dungeon=False):
    door_component=Door()
    #minimun 3 rooms
    numroom=0
    
    while numroom<3:
        somename=generator.dMap(MAP_WIDTH,MAP_HEIGHT)
        somename.makeMap(MAP_WIDTH,MAP_HEIGHT,200,probability_cor,number_of_rooms)
        numroom=len(somename.roomList)

    #translate
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            if somename.mapArr[y][x] != 2 and somename.mapArr[y][x]!=1 :
                map[x][y].blocked = False
                map[x][y].block_sight = False
            #doors
            if somename.mapArr[y][x]==4 or somename.mapArr[y][x]==3:                               
                door_component=Door()#normal door
                new_door = Object(x, y, '#', 'door', libtcod.orange, blocks=False,back_color=libtcod.darker_orange,door=door_component)
                objects.append(new_door)
                map[x][y].block_sight = True
                map[x][y].blocked=True
                
            if somename.mapArr[y][x]==5:                               
                door_component=Door()#secret door
                new_door = Object(x, y, ' ', 'secret door', libtcod.white, blocks=False,back_color=color_light_wall,door=door_component)
                objects.append(new_door)
                map[x][y].block_sight = True
                map[x][y].blocked=True
                
                
                
    
    #place stuff, player, enemies, treasure
    numroom=0
    for element in somename.roomList:
        numroom+=1
        h=element[0]
        w=element[1]
        x=element[2]
        y=element[3]
        xcenter=int((2*x+w)/2)
        ycenter=int((2*y+h)/2)
        room=Rect(x,y,w,h)
        
        if final_dungeon==False:#normal dungeon
            if numroom==1:#place player
                locate_player_and_allies(xcenter,ycenter)
            else:
                place_objects(room)
                
                
            if numroom==len(somename.roomList):#place stairs
                stairs=Object(xcenter,ycenter,'<','Stairs',color_light_ground,portal=Portal())
                
                objects.append(stairs)
                stairs.send_to_back()
        if final_dungeon==True:
            if numroom==1:#place player
                locate_player_and_allies(xcenter,ycenter)
            if numroom==2:#place final boss
                generate_enemy(xcenter,ycenter,boss=True)
            if numroom==3:#place treasure room
                locate_treasure_room(x,y,h,w)
            if numroom==4:#place exit
                stairs=Object(xcenter,ycenter,'#','Exit',color_light_ground,portal=Portal())
                
                objects.append(stairs)
                stairs.send_to_back()
                
                
                
                

        
def locate_treasure_room(x,y,h,w):
    number=0
    for X in range(w):
        for Y in range(h):
            if number<world.level:
                generate_treasure(X+x,y+Y,1,level=world.level)
            number+=1
            


def locate_player_and_allies(new_x,new_y):
    if True:
        if True:
            if True:
                player.x = new_x
                player.y = new_y

                #place friends
                for element in objects:
                    for y in range(MAP_HEIGHT):
                        for x in range(MAP_WIDTH):
                            if element is not player and element.fighter:
                                distance=(x-new_x)**2+(y-new_y)**2                                
                                if distance>0 and distance<4.1 and not is_blocked(x, y):
                                    element.x=x
                                    element.y=y    
def projectile_graphic(icon,color,ox,oy,dx,dy):
    target=Object(ox, oy,icon,'Target',color)
    objects.append(target)
    my_map=libtcod.map_new(MAP_WIDTH,MAP_HEIGHT)   
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            if not map[x][y].blocked:
                libtcod.map_set_properties(my_map, x, y, True, True)
    path = libtcod.path_new_using_map(my_map)
    libtcod.path_compute(path,ox,oy,dx,dy)
    for i in range(libtcod.path_size(path)):
        target.x,target.y=libtcod.path_get(path, i)
        #render the screen
        render_all() 
        libtcod.console_flush()
    objects.remove(target)
        
def cast_heal(self):
    #heal the player
    msg(self.name+' casts heal!')
    if self.fighter.hp == self.fighter.max_hp:
        return 'cancelled'
 
    msg(self.name+' wounds look better!', libtcod.light_violet)
    self.fighter.heal(int(self.fighter.lvl*1.5))

def cast_heal_all(self):
    #heal all the allyes
    msg(self.name+' casts heal all!')
    disponible_targets=False
    for element in objects:
        if element.fighter and element.fighter.alignment==self.fighter.alignment:
            if libtcod.map_is_in_fov(fov_map, element.x, element.y) and element.fighter.hp<element.fighter.max_hp:
                disponible_targets=True
                msg(element.name+' wounds look better!')
                element.fighter.heal(self.fighter.lvl)
    if disponible_targets==False:  #no enemy found within maximum range
        return 'cancelled'
def cast_fire_ball(self):
    msg(self.name+' casts fire ball!')
    #get closest monster
    monster = closest_monster(self,self.fighter.torch_radious,self.fighter.alignment)
    if monster is None:  #no enemy found within maximum range
        msg('No enemy in sight.', libtcod.red)
        return 'cancelled'
    projectile_graphic('*',libtcod.red,self.x,self.y,monster.x,monster.y)
    msg('The fire ball hits '+monster.name+'!')
    monster.fighter.take_damage(self.fighter.lvl+1,self.fighter)
def choose_dungeon():
        header='Select the size of the dungeon:\n\n'
        options=['Small (5 levels)','Medium (10 levels)','Large (15 levels)','Badass (20 levels)']
        chosen=None
        while chosen is None: 
            chosen=menu(header,options,40,1)
            if chosen == 0:
                world.final_level=5
            if chosen == 1:
                world.final_level=10
            if chosen == 2:
                world.final_level=15
            if chosen == 3:
                world.final_level=20

def cast_lightning(self):
    msg(self.name+' casts lightening!')
    #lightening damages all enemies in fov
    disponible_targets=False
    for element in objects:
        if element.fighter and element.fighter.alignment!=self.fighter.alignment:
            if libtcod.map_is_in_fov(fov_map, element.x, element.y):
                disponible_targets=True
                projectile_graphic('/',libtcod.blue,self.x,self.y,element.x,element.y)
                msg('The lightening ray hits '+element.name+'! ')
                element.fighter.take_damage(int(round(self.fighter.lvl/2+1)),self.fighter)
                
                
    
    if disponible_targets==False:  #no enemy found within maximum range
        msg('No enemy in sight.', libtcod.red)
        return 'cancelled'
    

    
    
def cast_paralyze(self):
    global objects
    msg(self.name+' casts paralyce!')
    #find closest enemy in-range and confuse it
    monster = closest_monster(self,self.fighter.torch_radious,self.fighter.alignment)
    if monster is None:  #no enemy found within maximum range
        return 'cancelled'
    projectile_graphic(':',libtcod.white,self.x,self.y,monster.x,monster.y)
    monster.fighter.paralysis=+self.fighter.lvl+2
    monster.back_color=libtcod.white
    msg('The ray paralyces ' + monster.name + '!')
def cast_blindness(self):
    global objects
    
    msg(self.name+' casts darkness!')
    for element in objects:
        if element.fighter and element.fighter.alignment!=self.fighter.alignment:
            if libtcod.map_is_in_fov(fov_map, element.x, element.y):
                element.fighter.blindness+=self.fighter.lvl+1
                msg(element.name+' is blind!')
                
    
def cast_summon(self):
    global objects
    msg(self.name+' casts summon!')
    #find closest tile to self
    ok=0
    
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            if not is_blocked(x,y) and libtcod.map_is_in_fov(fov_map,x,y):
                distance=(self.x-x)**2+(self.y-y)**2                                
                if distance>0 and distance<4.1:
                    newx=x
                    newy=y
                    ok=distance
    if ok==0:
        msg('There is no room for a summoning!')
        return 'cancelled'
    #create a friend
    name=generate_enemy(newx,newy,summon=1,alignment=self.fighter.alignment)
    msg('A '+name+ ' appears!')

    
    
    
SPELL_LIST=[cast_heal,cast_paralyze,cast_fire_ball,cast_heal_all,cast_lightning,
            cast_summon,cast_blindness]
SPELL_LIST_NAME=['heal', 'paralyce','fire ball','heal all','lightening',
                 'summoning','darkness']
SPELL_LIST_DESCRIPTION=['Heals yourself','Paralyces one enemie','Hits one enemy','Heals you and all your allies',
                        'Hits all the enemies','Summons a creature to help you',
                        'Blinds all enemies']


def closest_monster(self,max_range,alignment=None):
    global fov_map
    #find closest enemy, up to a maximum range, and in the fighters's FOV
    closest_enemy = None
    closest_dist = max_range + 1  #start with (slightly more than) maximum range
 
    for objectz in objects:
        if objectz.fighter and not objectz.fighter.alignment == alignment and libtcod.map_is_in_fov(fov_map, objectz.x, objectz.y):
            #calculate distance between this object and the player
            dist = self.distance_to(objectz)
            if dist < closest_dist:  #it's closer, so remember it
                closest_enemy = objectz
                closest_dist = dist
    return closest_enemy


            
def place_objects(room):
    
    #choose random number of monsters
    num_monsters = libtcod.random_get_int(0, 0, MAX_ROOM_MONSTERS)
 
    for i in range(num_monsters):
        #choose random spot for this monster
        x = libtcod.random_get_int(0, room.x1+1, room.x2-1)
        y = libtcod.random_get_int(0, room.y1+1, room.y2-1)
 
        #only place it if the tile is not blocked
        if not is_blocked(x, y):
            generate_enemy(x,y) 
            


    #choose random number of items
    num_items = libtcod.random_get_int(0, 0, MAX_ROOM_ITEMS)
 
    for i in range(num_items):
        #choose random spot for this item
        x = libtcod.random_get_int(0, room.x1+1, room.x2-1)
        y = libtcod.random_get_int(0, room.y1+1, room.y2-1)
 
        #only place it if the tile is not blocked
        if not is_blocked(x, y):
            generate_treasure(x,y,1,world.level/2+1)
 
 
def render_all():
    global fov_map, color_dark_wall, color_light_wall
    global color_dark_ground, color_light_ground
    global fov_recompute
 
    libtcod.map_compute_fov(fov_map, player.x, player.y, player.fighter.torch_radious, FOV_LIGHT_WALLS, FOV_ALGO)
    if True: 
        #go through all tiles, and set their background color according to the FOV
        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):
                visible = libtcod.map_is_in_fov(fov_map, x, y)
                wall = map[x][y].block_sight
                if not visible:
                    #if it's not visible right now, the player can only see it if it's explored
                    if map[x][y].explored:
                        if wall:
                            libtcod.console_put_char_ex(con, x, y, '#', color_dark_wall, color_dark_wall)
                        else:
                            libtcod.console_put_char_ex(con, x, y, '.', color_dark_ground,libtcod.BKGND_SET)
                    else:
                        libtcod.console_put_char_ex(con, x, y,'.', libtcod.black,libtcod.black)
    

                else:
                    #it's visible
                    if wall:
                        libtcod.console_put_char_ex(con, x, y,'#', color_light_wall, color_light_wall )
                    else:
                        libtcod.console_put_char_ex(con, x, y, '.', color_light_ground,libtcod.BKGND_SET)
                    #since it's visible, explore it
                    map[x][y].explored = True
 
    #draw all objects in the list, first items in floor, then fighters, and special effects
    for objectz in objects:
        if objectz.item:
            objectz.draw()
    for objectz in objects:
        if not objectz.item:
            objectz.draw()
    
    
    
    
 
    #blit the contents of "con" to the root console
    libtcod.console_blit(con, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 0, 0, 0)
 
    #show the player's stats
    libtcod.console_set_foreground_color(con, libtcod.white)
    libtcod.console_print_left(0, 0, SCREEN_HEIGHT - 1, libtcod.BKGND_NONE,
        'HP: ' + str(player.fighter.hp) + '/' + str(player.fighter.max_hp)
                               +' Dungeon level: '+ str(world.level)+'/'+str(world.final_level))

    # the game messages, one line at a time
    y = 0
    for (line, color) in game_msgs:
        libtcod.console_set_foreground_color(con, color)
        libtcod.console_print_left(0, 0, y, libtcod.BKGND_NONE, line)
        y=y+1
        
 
def player_move_or_attack(dx, dy):
    global fov_recompute
 
    #the coordinates the player is moving to/attacking
    x = player.x + dx
    y = player.y + dy
 
    #try to find an attackable object there, can be an ally
    target = None
    for objectz in objects:
        if objectz.fighter and objectz.x == x and objectz.y == y:
            target = objectz           
            if objectz.fighter.alignment == player.fighter.alignment: 
                #"teleport" the ally
                target.x=player.x
                target.y=player.y
                target = None
                                
            break   
 
    #attack if target found, move otherwise
    if target is not None:
        player.fighter.attack(target)
        
    else:
        player.move(dx, dy)
        fov_recompute = True

def show_character_info():
    global player
    #show the info and wait for a key
    header='Character Sheet\n\n'
    header+='Pablo the adventurer\n'
    header+='Level:'+str(player.fighter.lvl)+'\n\n'
    header+='Hit points:'+str(player.fighter.hp)+'/'+str(player.fighter.max_hp)+'\n'
    header+='Damage:1-'+str(player.fighter.max_damage)+'\n'
    header+='Bonus to hit:'+str(player.fighter.hit)+'\n'
    header+='Defense:'+str(player.fighter.AC)+'\n'
    
    options=['Continue']
    width=SCREEN_WIDTH-2
    menu(header, options, width)

def shout(alignment=None):
    global objects
    if alignment is not None:
        #create a menu
        header='Shout what?\n'
        options=['Follow me','Stop!','Attack!']
        width=SCREEN_WIDTH-2
        chosen=menu(header, options, width)
        for objectz in objects:
            if objectz.fighter is not None and objectz is not player:
                if objectz.fighter.alignment=='ally':            
                    if chosen==0:
                    #all allies AIfollow
                        objectz.ai=AIfollower()
                        msg("Follow me!")
                    if chosen==1:
                    #all allies BasicMonster
                        objectz.ai=AIstop()
                        msg("All Stop!")
                    if chosen==2:
                    #all allies BasicMonster
                        objectz.ai=BasicMonster()
                        msg("All kill!")
                    objectz.ai.owner = objectz
def open_close_doors(who):
    #check all the doors in distance==1
    for element in objects:
        if element.door:
            if element.distance_to(who)<2:
                element.door.use(who)
def show_readme():
    f=open('data/controls.txt')
    header='Controls:\n\n'
    for line in f:
        header+=str(line)
    header+='\n\n'
    options=[]    
    menu(header,options,MAP_WIDTH-2)
    f.close()
    
def show_intro(main=1):
    f=open('data/intro.txt')
    header='\n\n'
    for line in f:
        header+=str(line)
    header+='\n\n'
    options=[]
    menu(header,options,MAP_WIDTH-2)
    f.close()
def show_party():
    
    header="Party list\n"
    options=[]
    for element in objects:
        if element.fighter and element.fighter.alignment==player.fighter.alignment:
            friend=element.name+'('+str(element.fighter.hp)+'/'+str(element.fighter.max_hp)
            options.append(friend)
    menu(header,options,SCREEN_WIDTH-4)

def look():
    global NEW_MSG,target   
    target=Object(player.x, player.y,'^','Target',color=libtcod.red)
    objects.append(target)
    waiting=1
    chosen=None
    for element in objects:
        if element.name != 'door' and not(element.fighter and element.fighter.alignment==player.fighter.alignment) and waiting and libtcod.map_is_in_fov(fov_map,element.x,element.y)and element!=target:
            target.x=element.x
            target.y=element.y
            msg(element.name)
            #render the screen
            render_all() 
            libtcod.console_flush()
            #show messages 
            message(NEW_MSG)
            # delete mesages    
            del NEW_MSG
            NEW_MSG = ''
            
            key = libtcod.console_wait_for_keypress(True)                
            if int(key.c)<0:
                key_char=None
            else:
                key_char = chr(key.c)
            if (libtcod.KEY_ENTER == key.vk):
                waiting=0
                chosen=element
            if libtcod.KEY_ESCAPE==key.vk:
                waiting=0
    objects.remove(target)
    if chosen:
        return chosen
                

                
def fire_ranged(self):
    #get closest monster
    monster = closest_monster(self,self.fighter.torch_radious,self.fighter.alignment)
    if monster is None:  #no enemy found within maximum range
        msg('No enemy in sight.', libtcod.red)
        return 'cancelled'
    #if distance was more than 1 tile
    if monster.distance_to(self)>1.5:
        msg(self.name+' shoots!')
        projectile_graphic('/',libtcod.dark_grey,self.x,self.y,monster.x,monster.y)
        self.fighter.wait+=4
    else:#normal attack but with less bonus
        self.fighter.hit=int(self.fighter.hit/2)
    self.fighter.attack(monster)
    
    
def use_bow():
    #search for a equipped bow
    shoot=0
    for element in inventory:
        if element.item.equip_class and element.item.equip_class.equipped:
            if element.item.type=='bow':
                fire_ranged(player)
                shoot=1
    if shoot==0:
        msg('You dont have a bow')
    
def exit_menu():
    header='EXIT?'
    options=['YES']
    chosen=menu(header,options,20)
    if chosen==0:
        
        save_game()
        menu("Game Saved!",options,20)
        return 'exit'  #exit game
    else:
        return 'didnt-take-turn'
def save_game():
    #save player
    save_object=open("data/spl.p","w")
    pickle.dump(player,save_object)
    save_object.close()
    #save objects list
    objects.remove(player)
    save_object=open("data/sob.p","w")
    pickle.dump(objects,save_object)
    save_object.close()
    #save map
    save_object=open("data/sma.p","w")
    pickle.dump(map,save_object)
    save_object.close()
    #save world
    save_object=open("data/swo.p","w")
    pickle.dump(world,save_object)
    save_object.close()
    #save inventory
    save_object=open("data/sin.p","w")
    pickle.dump(inventory,save_object)
    save_object.close()
    
def check_expo():
    number=[]
    
    for i in range(101):        
        number.append(i)    
    for i in range(101):        
        number[i]=0
    for i in range(2000):
        num=getexp()     
        #print num
        number[num]+=1
        
        #libtcod.console_wait_for_keypress(True) 
    print number
    print number[0]
                                            

    

def get_random_noise():
    return int((libtcod.noise_fbm_perlin(libtcod.noise_new(1),[0.9],32.0)+0.45)*100)
def handle_keys():
    global fov_map
    global fov_recompute
    global map
    global player
    
    key = libtcod.console_wait_for_keypress(True)  #turn-based
    if int(key.c)<0:
        key_char=None
    else:
        key_char = chr(key.c)
    if key.vk == libtcod.KEY_TAB:
        1+1
    if key.vk == libtcod.KEY_ESCAPE:
        return exit_menu()
        
    
 
    if game_state == 'playing':
        #movement keys
        if libtcod.console_is_key_pressed(libtcod.KEY_UP) or key_char == '8':
            player_move_or_attack(0, -1)
 
        elif libtcod.console_is_key_pressed(libtcod.KEY_DOWN)or key_char == '2':
            player_move_or_attack(0, 1)
 
        elif libtcod.console_is_key_pressed(libtcod.KEY_LEFT)or key_char == '4':
            player_move_or_attack(-1, 0)
 
        elif libtcod.console_is_key_pressed(libtcod.KEY_RIGHT)or key_char == '6':
            player_move_or_attack(1, 0)
        elif key_char=='5':
            player_move_or_attack(0, 0)           

        elif libtcod.console_is_key_pressed(libtcod.KEY_RIGHT)or key_char == '1':
            player_move_or_attack(-1, +1)
        elif libtcod.console_is_key_pressed(libtcod.KEY_RIGHT)or key_char == '3':
            player_move_or_attack(1, +1)
        elif libtcod.console_is_key_pressed(libtcod.KEY_RIGHT)or key_char == '7':
            player_move_or_attack(-1, -1)
        elif libtcod.console_is_key_pressed(libtcod.KEY_RIGHT)or key_char == '9':
            player_move_or_attack(1, -1)

            
        else:
        
            #test for other keys

 
            if key_char == 'g':
                #pick up an item (picks the last appended = top side)
                targetobj=None
                options_name=[]
                options_item=[]
                nitems=0
                for element in objects:  #look for an item in the player's tile
                    if element.x == player.x and element.y == player.y and element.item and nitems<26:
                        #object.item.pick_up()
                        options_name.append(element.name)
                        options_item.append(element)
                        nitems+=1
                        
                if len(options_name)>1:
                    targetobj=menu('Which item to pick up?',options_name,SCREEN_WIDTH-2)                    
                    if targetobj!=None:
                        options_item[targetobj].item.pick_up()
                        return 1
                elif len(options_name)==1:
                    options_item[0].item.pick_up()
                    return 1
                
                    
                    
                
            if key_char == 'f':
                use_bow()
                
            if key_char=='p':
                show_party()
                                       
            if key_char=='m':
                #show message log
                 print_msg_log()
                
            if key_char == 'i':
                
                #show the inventory; if an item is selected, describe it
                chosen_item = inventory_menu('Press the key next to an item to describe it\n')
                if chosen_item is not None:
                    chosen_item.describe()

                    
            if key_char == 'u':                
                #show the usable items; if an item is selected, use
                chosen_item = inventory_menu('Press the key next to an item to use it\n')
                if chosen_item is not None:
                    if chosen_item.owner.special is None:
                        chosen_item.use()
                        return 1
                    else:
                        if chosen_item.equip_class.equipped:
                            for element in chosen_item.owner.special:
                                if element.charged:
                                    player.special[0].cast()
                                    chosen_item.owner.special[0].charged=False
                                    return 1
                                else:
                                    msg('The magic item is discharged!')
                        else:
                            msg('Must equip first')
                    
            if key_char == 'w':                
                #show the equipable items; if an item is selected, use
                chosen_item = inventory_menu('Press the key next to an item to equip it\n')
                if chosen_item is not None:
                    if chosen_item.equip_class is not None:
                        chosen_item.equip_class.equip()
                        return 1
                    else:
                        msg('This cant be equipped')
            if key_char == 'h':
                show_readme()

            if key_char == 'l':
                #look command
                look()
                
            if key_char == 'c':
                #character information
                show_character_info()
            if key_char == 's':
                shout(player.fighter.alignment)
                
            if key_char=='o':
                return open_close_doors(player)
                

            if key_char == 'd':
                #show the inventory; if an item is selected, drop it
                chosen_item = inventory_menu('Press the key next to an item to drop it, or any other to cancel.\n')
                if chosen_item is not None:
                    if chosen_item.equip_class:
                        if chosen_item.equip_class.equipped is not True:
                            chosen_item.drop()
                            return 1
                        else:
                            msg('Unequip first!')
                    else:
                        chosen_item.drop()
                        return 1

            if key_char=='<' or key_char=='>':
                #if the player is on stairs, create a new map
                x=player.x
                y=player.y
                for element in objects:
                    if x==element.x and y==element.y:
                        if element.portal:
                            element.portal.use()
                            return 1

               

            return 'didnt-take-turn'
            
 
def player_death(player,monster):
    global NEW_MSG
    #the game ended!
    global game_state
    msg('You died!')
    game_state = 'dead'
 
    #for added effect, transform the player into a corpse!
    player.char = '%'
    player.color = libtcod.dark_red
 
def monster_death(monster,killer):
    global objects
    zom=False
    if monster.special:
        for elem in monster.special:
            if elem.name=='zombie' and elem.resurrection_probability>libtcod.random_get_int(0,0,100):
                zom=True
                elem.resurrection_probability-=10
    
    
    msg(monster.name.capitalize() + ' is dead!')
    if zom:
        monster.fighter.wait+=1
        msg(monster.name+" revives!")
        monster.fighter.hp=monster.fighter.max_hp
        monster.fighter.lvl+=1
    else:
        killer.get_experience(monster.fighter.exp)
        generate_treasure(monster.x,monster.y,int(round(monster.fighter.lvl/4)),int(round(monster.fighter.lvl/1.5+1)))
        objects.remove(monster)

    
def boss_death(monster,killer):
    global objects
    world.finished=True
    monster_death(monster,killer)

def actualizebonuses():
    global objects

                

    
    for objectf in objects:
        if objectf.fighter:            
            bonushit=0
            bonushp=0
            bonusac=0
            bonusmaxdmg=0

          
                
            if objectf == player:
                
                #if is the player add the items bonus

                for item in inventory:#check in the inventory the equipped items with bonusses
                    if item.item.equip_class!=None:
                        if item.item.equip_class.equipped==True:
                            bonushit+=item.item.equip_class.hit#bonus to hit
                            bonushp+=item.item.equip_class.maxhp#bonus to maxhp
                            bonusac+=item.item.equip_class.ac#bonus to ac
                            bonusmaxdmg+=item.item.equip_class.maxdmg
                            
                
            #calculate new bonuses
            objectf.fighter.hit=bonushit+objectf.fighter.basehit
            objectf.fighter.max_hp=bonushp+objectf.fighter.basehp
            objectf.fighter.AC=bonusac+objectf.fighter.baseAC+10
            #if paralyced, AC=0
            if objectf.fighter.paralysis>0:
                objectf.fighter.AC=0

            
                
            
            
            objectf.fighter.max_damage=bonusmaxdmg+objectf.fighter.basedamage
            if objectf.fighter.max_damage<1:
                objectf.fighter.max_damage=1
            
def print_msg_log():
    global msg_log
    header='MESSAGE LOG'
    options=msg_log
    menu(header,options,SCREEN_WIDTH-2)
    
    
    
def message(new_msg, color = libtcod.white):
    #split the message if necessary, among multiple lines
    global msg_log
    new_msg_lines = textwrap.wrap(new_msg, MSG_WIDTH)
    y=0 
    for line in new_msg_lines:
        #if the buffer is full, remove the first line to make room for the new one
        
        y=y+1
        #add the new line
        #if is the last line dont put []
        if len(new_msg_lines) > y:
            game_msgs.append( ((line + '...'), color)) 
        else:
            game_msgs.append( (line , color) )

        #render the screen
        render_all() 
        libtcod.console_flush()
        #erase all objects at their old locations, before they move
        for objectz in objects:
            objectz.clear()
        
        if len(new_msg_lines) > y:
            #wait for key SPACE
            waiting=1
            while ( waiting ):   
                key = libtcod.console_wait_for_keypress(True) 
                #if (libtcod.KEY_ENTER == key.vk):
                    #waiting=0
                waiting=0
    
        if len(game_msgs) > MSG_HEIGHT-1:
                del game_msgs[0]

        #message log buffer
        msg_log.append(line)
        if len(msg_log) > 25:
                del msg_log[0]

def read_data():
    #monster name data
    f=open('data/enemy_names.txt') 
    for line in f:
        name=''
        iterations=len(str(line))
        i=0
        while i<iterations-1:                      
            name+=str(line)[i]
            i+=1
        MONSTER_NAME_LIST.append(name)
        
    
def main_menu():

    header='WELCOME TO PABLOQUEST! v0.2\nCreated by Cebollinos\n\n'
    options=['New Game','Continue Game','Exit']
    cool=False
    while cool==False:
        select=menu(header,options,SCREEN_WIDTH-2,1)
        if select==0:
            return 'new'
        if select==1:
            return 'load'
        if select==2:
            return 'exit'

def create_new_game():
    global objects
    world=World()
    choose_dungeon()
    #the list of objects with just the player
    objects = [player]     
    #generate map (at this point it's not drawn to the screen)
    make_map()
    #create a friend
    fighter_component = Fighter(hp=15, AC=3, max_damage=6,hit=3,
                                death_function=monster_death, alignment='ally')                           
    ai_component=AIfollower()
    friend = Object(player.x, player.y+1, 'Q', 'Quest', libtcod.red, blocks=True,
                    fighter=fighter_component,ai=ai_component)
    objects.append(friend)
def load_game():
    global objects
    global map
    global world
    global player
    global inventory
    #load player
    save_object=open("data/spl.p","r")
    player=pickle.load(save_object)
    save_object.close()
    #save objects list
    save_object=open("data/sob.p","r")
    objects=pickle.load(save_object)
    save_object.close()
    objects.append(player)
    #save map
    save_object=open("data/sma.p","r")
    map=pickle.load(save_object)
    save_object.close()
    #save world
    save_object=open("data/swo.p","r")
    world=pickle.load(save_object)
    save_object.close()
        #save inventory
    save_object=open("data/sin.p","r")
    inventory=pickle.load(save_object)
    save_object.close()

    
def playgame():
    global NEW_MSG
    while not libtcod.console_is_window_closed():
 
        #render the screen
        render_all() 
        libtcod.console_flush()

        #erase all objects at their old locations, before they move
        for objectz in objects:
            objectz.clear()

        #calculate all bonusses for the player
        actualizebonuses()

        #keep messages until player stops waiting    
        if player.fighter.wait==0:
            #show messages 
            message(NEW_MSG)
            # delete mesages    
            del NEW_MSG
            NEW_MSG = ''

        
        #player take action
        player_action=player.fighter.play()   

        if game_state=='dead':
            print_msg_log()
            msg("Press ESCAPE to exit")
            render_all()
            libtcod.console_flush()
            
        if player_action == 'exit':
            break
     
        #let monsters take their turn
        if game_state == 'playing' and player_action != 'didnt-take-turn':
            for element in objects:
                if element.ai and not element == player:
                    libtcod.map_compute_fov(fov_map,element.x , element.y, element.fighter.torch_radious , FOV_LIGHT_WALLS, FOV_ALGO)
                    element.fighter.play()
                    
                   

    
#############################################
# Initialization & Main Loop
#############################################
 
libtcod.console_set_custom_font('font.png', libtcod.FONT_TYPE_GREYSCALE | libtcod.FONT_LAYOUT_TCOD)
libtcod.console_init_root(SCREEN_WIDTH, SCREEN_HEIGHT, 'Pablo Quest', False)
libtcod.sys_set_fps(LIMIT_FPS)
con = libtcod.console_new(SCREEN_WIDTH, SCREEN_HEIGHT)
#read data
read_data()
#Main menu
new_load='asd'

while new_load!='exit':
    new_load=main_menu()
    #create the object of the World
    world = World()

    #create the list of game messages and their colors, starts empty
    game_msgs = []
    msg_log=[]
    objects=[]
    inventory=[]

    #create object representing the player
    fighter_component = Fighter(hp=10, AC=2, max_damage=6,hit=1, death_function=player_death, alignment='ally')
    ai_component=AiPlayer()
    special_list=[]
    special_list.append(Mage())
    player = Object(0, 0, '@', 'Pablo', libtcod.white, blocks=True,
                    fighter=fighter_component,ai=ai_component,special=special_list)
     

    if new_load=='new':
        create_new_game()
        show_intro()
    if new_load=='load':
        load_game()
        if player.fighter.hp<1:
            new_load='exit'

    if new_load!='exit': 
        #create the FOV map, according to the generated map
        fov_map = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):
                libtcod.map_set_properties(fov_map, x, y, not map[x][y].blocked, not map[x][y].block_sight)
         
        fov_recompute = True
        game_state = 'playing'
        player_action = None
        target=None

        
        msg( 'You enter the dungeon...' )
        playgame()
                    
        
        

