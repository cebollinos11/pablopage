from distutils.core import setup
import py2exe

# Run 'python win_setup.py py2exe'

opts = {
    "py2exe": {
        "ascii": True,
        "excludes": ["_ssl"],
        "compressed": True,
        "packages": ["encodings"],
        "excludes": ['_ssl',  # Exclude _ssl
                   'pyreadline', 'difflib', 'doctest', 'locale',
                   'optparse', 'calendar'],  # Exclude standard library
        'bundle_files': 1,
    }
}

win = [
        {
            "script": "main.py",
            "icon_resources": [(0, "icon.ico")]
        }
    ]

setup(options=opts, windows=win, zipfile=None)
